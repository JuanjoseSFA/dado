# PlayTIC
Más que una herramienta, en esta serie de videos programaremos varias herramientas muy interesantes con ayuda de Javascript y otras librerías.

Ver: https://f3rjara.github.io/PlayTIC/

[![Watch the video](https://i.ibb.co/pLkKMJZ/CAP-1.png)](https://www.youtube.com/watch?v=zgU8qedad0w)
